<!-- <?php 
//$idSubcat=$_REQUEST['idSubcat'];
//$idCategoria=$_REQUEST['idCategoria'];
//$posicion=$_REQUEST['posicion'];
//$articulosPorPagina=$_REQUEST['articulosPorPagina'];
$listado=Articulos::listadoArticulos(0, 0, $idSubcat, $idCategoria);    
$datos=Subcategorias::datosCategoriaSubcat($idSubcat);


?> -->


<section id="dulces" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <?php 
						echo "<h2>".$datos['nombreCategoria']."</h2>
								<h3>".$datos['nombreSubcat']."</h3>";
					?>
                    <hr class="bottom-line">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
<?php 	
	$i=0;	
    $total= count($listado)-1;
    $losqueyasalieron=array();


    for ($i=0; $i < 6; $i++) {

        $aleatorio=rand(0, $total);
        while (in_array($aleatorio, $losqueyasalieron)) {
            $aleatorio=rand(0, $total);
        }
        $losqueyasalieron[]=$aleatorio;

        echo "<div class='col-md-4 col-sm-6 padleft-right'>
                    <figure class='imghvr-fold-up'>
                        <img src='imagenes/".$listado[$aleatorio]['foto']."' class='img-responsive'>
                        <figcaption>
                            <h3>".$listado[$aleatorio]['nombreArticulo']."</h3>
                            <p>".$listado[$aleatorio]['descripcion']."</p>
                            <h4>".$listado[$aleatorio]['precio']."€</h4>
                            <a href='indexarticulo.php?idArticulo=".$listado[$aleatorio]['idArticulo']."'></a>
                        </figcaption>
                        
                    </figure>
                </div>";
    
        if ($i%3==0) {
    		echo "<div class='clearfix visible-md'></div>";
    		
    	}            
    }
          
                
                
 ?>   
            </div>
        </div>
    </section>
