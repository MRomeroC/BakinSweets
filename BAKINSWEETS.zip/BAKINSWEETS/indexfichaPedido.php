<?php
include_once "clases.php";
include_once "header.php";
include_once "fichaPedido.php";
include_once "footer.php";    
?>