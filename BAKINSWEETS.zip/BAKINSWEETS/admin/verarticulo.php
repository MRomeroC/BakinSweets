<?php 

if (isset($_REQUEST['verArticulo'])) {
	$idArticulo=$_REQUEST['idArticulo'];

	$listado=Articulos::datosArticulo($idArticulo);
}

 ?>

 <table border="1">
 	<tr>
    	<th>Categoría</th>
 		<th>Subcategoría</th>
		<th>Artículo</th>
		<th>Descripción</th>
 		<th>Precio</th>
 		<th>Stock</th>
		<th>Foto</th>
 	</tr>
<?php 

  echo "<tr>";
  echo "<td>".$listado['nombreCategoria']."</td>";
  echo "<td>".$listado['nombreSubcat']."</td>";
  echo "<td>".$listado['nombreArticulo']."</td>";
  echo "<td>".$listado['descripcion']."</td>";
  echo "<td>".$listado['precio']."</td>";
  echo "<td>".$listado['stock']."</td>";
  echo "<td><img src='".$listado['foto']."' alt='".$listado['nombreArticulo']."' width='100'></td>";
  echo "</tr>";

 ?> 	
 </table>
 <hr>
 <a href="admin.php?menu=31">Volver</a>

