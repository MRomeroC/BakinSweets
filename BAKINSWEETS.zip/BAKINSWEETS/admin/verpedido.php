<?php  
include_once "../clases.php";

$idPedido=$_REQUEST['idPedido'];
$datos=LineasPedidos::muestraLineaPedido($idPedido);

?>

  <link rel="stylesheet" href="../css/misestilos.css">
    <div class="container">
        <div class="row">
            <div class="header-section text-center">
            	<h2>Mi pedido</h2>
            </div>
			<div class="row cta-2-txt"">
			<table class="tablaPedidos">
				<caption>Desglose del pedido <?=$idPedido ?></caption>
				<thead>
					<tr>
						<th>Artículo</th>
						<th>Cantidad</th>
						<th>Precio</th>
						<th>Total</th>
					</tr>
				</thead>
				<tbody>
<?php  
$totalfinal=0;
foreach ($datos as $key => $value) {
	$total=$value['precioPedido']*$value['cantidad'];
	$totalfinal+=$total;
	echo "<tr>
	<td>".$value['nombreArticulo']."</td>
	<td>".$value['cantidad']."</td>
	<td>".$value['precioPedido']."</td>
	<td>$total</td>
	</tr>";
}
echo "<tr><td colspan='3'>Total....</td>
<td>$totalfinal</td>
</tr>";

?>
				</tbody>
			</table>
    </div>
</section>
 <hr>
 <a href="index.php">Ir al menú principal</a>