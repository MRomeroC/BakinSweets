<?php 
include_once "clases.php";
include_once "header.php";
include_once "parteusuario.php";
include_once "footer.php";  
?>