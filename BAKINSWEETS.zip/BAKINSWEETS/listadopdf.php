<?php 
//librería para crear pdf 
//include_once "../fpdf/fpdf.php";
include_once "clasepdf.php";
$idPedido=$_REQUEST['idPedido'];
$idUsuario=$_REQUEST['idUsuario'];

include_once "clases.php";

//crear un objeto de la clase fpdf

$datos=Pedidos::datosPedido($idPedido);
$lineas=LineasPedidos::muestraLineaPedido($idPedido);


$mipdf=new PDF();

//crear una hora
$mipdf->AddPage();
$mipdf->SetTextColor(92,51,23);
$mipdf->SetDrawColor(92,51,23);
$mipdf->SetFont('Arial','',16);
$mipdf->Cell(190,10,utf8_decode("Nº Factura: ".$datos['idPedido']),0,0,'R');
$mipdf->Ln();
$mipdf->SetFont('Arial','',12);
$mipdf->Cell(190,5,utf8_decode("Fecha: ".$datos['fechaPedido']),0,0,'R');
$mipdf->Image('img/logo.png',3,7,100,18,'PNG','$servidor/bakinsweets.php');
$mipdf->Ln();
$mipdf->Ln();

$mipdf->SetTextColor(92,51,23);
$mipdf->SetFont('Arial','B',24);
$mipdf->Cell(190,40,utf8_decode("Factura de Pedido"),0,1,'C');



$mipdf->SetFont('Arial','B',18);
$mipdf->Cell(0,10,utf8_decode("Datos Cliente"),0,0,'L');
$mipdf->Ln();
$mipdf->SetFont('Arial','',12);
$mipdf->Cell(0,5,$datos['nombre']." ".utf8_decode($datos['apellidos']) ,0,0,'L');
$mipdf->Ln();
$mipdf->Cell(0,5,utf8_decode($datos['direccion']),0,0,'L');
$mipdf->Ln();
$mipdf->Cell(0,5,utf8_decode($datos['ciudad'])." ".$datos['cp'],0,1,'L');

$mipdf->Ln();
$mipdf->Ln();


$mipdf->SetFont('Arial','B',18);
$mipdf->Cell(0,10,utf8_decode("Desglose Pedido"),0,0,'L');
$mipdf->Ln();

$mipdf->SetFillColor(199,45,73);
$mipdf->SetTextColor(255,255,255);
$mipdf->SetFont('Times','B',16);
$mipdf->Cell(85,10,utf8_decode("Artículo"),1,0,'C',1);
$mipdf->Cell(35,10,"Cantidad",1,0,'C',1);
$mipdf->Cell(35,10,"Precio",1,0,'C',1);
$mipdf->Cell(35,10,"Total",1,0,'C',1);
$mipdf->Ln();

$mipdf->SetTextColor(92,51,23);
$totalfinal=0;
foreach ($lineas as $key => $value) {
	$total=$value['cantidad']*$value['precioPedido'];
	$totalfinal+=$total;
	$mipdf->SetFont('Arial','', 14);
	$mipdf->Cell(85,10,utf8_decode($value['nombreArticulo']),1,0,'C');
	$mipdf->Cell(35,10,utf8_decode($value['cantidad']),1,0,'C');
	$mipdf->Cell(35,10,utf8_decode($value['precioPedido']),1,0,'C');
	$mipdf->Cell(35,10,utf8_decode($total),1,0,'C');
	$mipdf->Ln();
}


$mipdf->SetFont('Arial','B', 14);
$mipdf->Cell(155,10,"Total",1,0,'C');
$mipdf->SetTextColor(255,255,255);
$mipdf->Cell(35,10,utf8_decode($totalfinal),1,0,'C',1);

$mipdf->Output();

?>