<?php 
//librería para crear pdf 
//include_once "../fpdf/fpdf.php";
include_once "clasepdf.php";
$idPedido=$_REQUEST['idPedido'];
$idUsuario=$_REQUEST['idUsuario'];

include_once "clases.php";

//crear un objeto de la clase fpdf

$datos=Pedidos::datosPedido($idPedido);
$lineas=LineasPedidos::muestraLineaPedido($idPedido);


$mipdf=new PDF();

//crear una hora
$mipdf->AddPage();
$mipdf->SetFont('Arial','B',24);
$mipdf->Cell(0,20,utf8_decode("Factura de Pedido"),1,1,'C');

$mipdf->SetFont('Arial','',16);
$mipdf->Cell(100,10,utf8_decode("Número Fra:"));
$mipdf->Cell(10,10,$datos['idPedido']);
$mipdf->Ln();
$mipdf->Cell(100,10,utf8_decode("Fecha:"));
$mipdf->Cell(10,10,$datos['fechaPedido']);
$mipdf->Ln();




/*$mipdf->SetFillColor(232,232,232);
$mipdf->SetFont('Times','B',16);
$mipdf->Cell(100,20,utf8_decode("Artículo"),1,0,'C',1);
$mipdf->Cell(45,20,"Cantidad",1,0,'C',1);
$mipdf->Cell(45,20,"Precio",1,0,'C',1);
$mipdf->Cell(45,20,"Total",1,0,'C',1);
$mipdf->Ln();

$totalfinal=0;
foreach ($listado as $key => $value) {
	$total=$value['cantidad']*$value['precioPedido'];
	$totalfinal+=$total;
	$mipdf->SetFont('Arial','', 14);
	$mipdf->Cell(100,10,utf8_decode($value['nombreArticulo']),1,0,'C');
	$mipdf->Cell(45,10,utf8_decode($value['cantidad']),1,0,'C');
	$mipdf->Cell(45,10,utf8_decode($value['precioPedido']),1,0,'C');
	$mipdf->Cell(45,10,utf8_decode($total),1,0,'C');
	$mipdf->Ln();
}

$mipdf->Cell(45,10,utf8_decode($totalfinal),1,0,'C');*/

$mipdf->Output();

?>