<?php 
if (isset($_SERVER['HTTPS'])) {
  $servidor="https://".$_SERVER['HTTP_HOST']."/";
} else {
  $servidor="http://".$_SERVER['HTTP_HOST']."/Curso2018/Proyecto/BAKINSWEETS/";
}

session_start();

// debo crear un objeto de tipo Sesiones
$misesion = new Sesiones();

if (isset($_REQUEST['acceso'])) {
  $usuario=$_REQUEST['loginid'];
  $clave=$_REQUEST['loginpsw'];
  if ($datos=Usuarios::buscaUsuario($usuario,$clave)) {
    $misesion->iniciaLogin($usuario);
  }else{
    ?>
  <script>
  alert("Usuario/password NO validos");
  </script>
    <?php
  }
}

// cerrar sesion de usuario
if (isset($_REQUEST['cerrar'])) {
  $misesion->finLogin();
}

//inicializar el carrito
$micarrito=new Carrito();

//agregar articulo al carrito
if (isset($_REQUEST['alcarrito'])) {
  $idArticulo=$_REQUEST['idArticulo'];
  $datos=Articulos::datosArticulo($idArticulo);

  $nombreArticulo=$datos['nombreArticulo'];
  $precio=$datos['precio'];

  $micarrito->addArticulo($idArticulo,$nombreArticulo,$precio);
}

//vaciar carrito

if (isset($_REQUEST['vaciar'])) {
  $micarrito->vaciarCarrito();
  $micarrito=new Carrito();
}

//eliminar un artículo del carrito
if (isset($_REQUEST['eliminar'])) {
  $idArticulo=$_REQUEST['idArticulo'];
  $micarrito->deleteArticulo($idArticulo);
}

//modificar cantidad de articulos en el carrito
if (isset($_REQUEST['modificarCarrito'])) {
  $idArticulo=$_REQUEST['idArticulo'];
  $cantidad=$_REQUEST['cantidad'];
  $micarrito->modificarCarrito($idArticulo,$cantidad);
}


// guardar carrito después de pagar
include_once "guardarcarrito.php";


 ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BakinSweets</title>
    <meta name="description" content="Venta de dulces caseros">
    <meta name="keywords" content="dulces, sweets, galletas, cupcakes, tartas">

    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans|Candal|Alegreya+Sans">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" integrity="sha384-G0fIWCsCzJIMAVNQPfjH08cyYaUtMwjJwqiRKxxE/rx96Uroj1BtIQ6MLJuheaO9" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/imagehover.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="css/misestilos.css">
</head>

<body>
    <!--Navigation bar-->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
                <a class="navbar-brand" href="index.php">Bakin<span>Sweets</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">


                  
                  <li class='dropdown'><a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>Nosotros<span class='caret'></span></a>
                          <ul class='nav navbar-nav  navbar-right dropdown-menu'>
                          <li><a href='index.php#pasteleria'>La Pastelería</a></li>
                          <li><a href='index.php#reposteros'>Nuestros Reposteros</a></li>
                          <li><a href='index.php#dulces'>Nuestros Dulces</a></li>
                        </ul>

                        </li>
                      

                    <?php 
                    $listadoCategoria=Categorias::listadoCategorias();
                    foreach ($listadoCategoria as $key => $value) {
                        echo "<li class='dropdown'><a href='#".$value['idCategoria']."'class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>".$value['nombreCategoria']."<span class='caret'></span></a>
                          <ul class='nav navbar-nav dropdown-menu'>";
                          $listadoSubcat=Subcategorias::listadoSubcategorias($value['idCategoria']);
                          foreach ($listadoSubcat as $key2 => $value2) {
                          echo "<li><a href='indexarticulos.php?posicion=0&articulosPorPagina=6&idSubcat=".$value2['idSubcat']."&idCategoria=".$value2['idCategoria']."'>".$value2['nombreSubcat']."</a></li>";
                        }

                        echo "</ul>
                        </li>";

                    }?>    
                    
                    <li><a href="indexcontacto.php">Contáctanos</a></li>

                    <?php if ($misesion->estadoLogin()) { ?>
                    <li><a href="indexparteusuario.php"><?= $misesion->getUsuario() ?></a></li>
                    <li><a href="javascript:void(0)" onClick="window.location='bakinsweets.php?cerrar=303'" title="cerrar sesión"> <i class="fas fa-sign-out-alt"></i></a></li>
                    <?php
                    }else{
                    ?>
                    <li><a href="#" data-target="#login" data-toggle="modal" title="login">Entrar <i class="fas fa-sign-in-alt"></i></a></li>
                    <?php } ?>
                    <li><a href="indexcarrito.php"><i class="fas fa-shopping-cart"></i>(<?=$micarrito->getArticulosTotal();?>)</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!--/ Navigation bar-->
      <!--Modal box-->
  <div class="modal fade" id="login" role="dialog">
    <div class="modal-dialog modal-sm">

      <!-- Modal content no 1-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title text-center form-title">Iniciar Sesión</h4>
        </div>
        <div class="modal-body padtrbl">

          <div class="login-box-body">
            <p class="login-box-msg">Inicia sesión para comenzar</p>
            <div class="form-group">
              <form name="" id="loginForm" action="index.php" method="post">
                <div class="form-group has-feedback">
                  <!----- username -------------->
                  <input class="form-control" placeholder="Usuario (email)" id="loginid" type="text" name="loginid" />
                  <span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginid"></span>
                  <!---Alredy exists  ! -->
                  <span class="form-control-feedback"><i class="fas fa-user"></i></span>
                </div>
                <div class="form-group has-feedback">
                  <!----- password -------------->
                  <input class="form-control" placeholder="Contraseña" id="loginpsw" type="password" name="loginpsw" />
                  <span style="display:none;font-weight:bold; position:absolute;color: grey;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginpsw"></span>
                  <!---Alredy exists  ! -->
                  <span class="form-control-feedback"><i class="fas fa-unlock-alt"></i></span>
                </div>
                <div class="row">
                  <div class="col-xs-12">
                    <div class="checkbox icheck">
                      <label>
                                <input type="checkbox" id="loginrem" > Recuérdame
                              </label>
                    </div>
                  </div>
                  <div class="col-xs-12">
                    <button type="submit" class="btn btn-green btn-block btn-flat" name="acceso">Entrar</button>
                  </div>
                  <div class="col-xs-12 margen">
                    <p>¿No tienes cuenta? <a href="indexaltausuario.php">Regístrate</a></p>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
  <!--/ Modal box-->
    <!--Banner-->
    <div class="banner">
        <div class="bg-color">
            <div class="container">
                <div class="row">
                    <div class="banner-text text-center">
                        <div class="text-border">
                            <h2 class="text-dec">Pasión por el dulce</h2>
                        </div>
                        <div class="intro-para text-center quote">
                            <p class="big-text">TIENDA</p>
                            <p class="small-text">No sólo los ingredientes hacen rico a un pastel. El amor con que se hace le da el toque especial.</p>
                        </div>

                        <a href="#pasteleria" class="mouse-hover">
                            <div class="mouse"></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Banner-->