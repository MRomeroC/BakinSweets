$(document).ready(function($){

var emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i,
	tlfoExp = /^[9|6|7][0-9]{8}$/;

	$("#formulario").submit(function(){
		if ($("#email").val()=="") {

		}

		if (error) {
			
		}
	});
});