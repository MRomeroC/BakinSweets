$(document).ready(function(){

$("#formulario").submit(function(){

	var nombre, email, asunto, comentario, url;

	nombre=$("#nombre").val();
	email=$("#email").val();
	asunto=$("#asunto").val();
	comentario=$("#comentario").val();

	url="../envioformulario.php";

	$.ajax({
		type: "post",
		url: url,
		data: {nombre: nombre, email: email, asunto: asunto, comentario: comentario},

		success: function(respuesta){
			$("#mensaje").html(respuesta);
			$("#nombre").val("");
			$("#email").val("");
			$("#asunto").val("");
			$("#comentario").val("");
			//limpiamos el cuestionario ya que no se recarga la página
		}
	});

}

});


