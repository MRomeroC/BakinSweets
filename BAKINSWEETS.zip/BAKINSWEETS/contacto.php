
<!--Contacto-->
    <section id="contacto" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>Contacta con nosotros</h2>
                    <p>Si quieres ponerte en contacto con nosotros, <br>déjanos tus datos en este formulario y te contestaremos en la mayor brevedad posible.</p>
                    <hr class="bottom-line">
                </div>
                <div id="mensaje">
                    <?=$mensaje ?>                        
                 </div>
                <form action="indexcontacto.php" method="post" id="formulario" role="form">
                    <div class="col-md-6 col-sm-6 col-xs-12 left">
                        <div class="form-group">
                            <input type="text" name="nombre" class="form-control form" id="nombre" placeholder="Tu nombre" data-rule="minlen:4" data-msg="Por favor, introduce al menos 4 caracteres" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Tu email" data-rule="email" data-msg="Por favor, introduce un email válido" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="asunto" id="asunto" placeholder="Asunto" data-rule="minlen:4" data-msg="Por favor, introduce al menos 8 caracteres" />
                            <div class="validation"></div>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12 right">
                        <div class="form-group">
                            <textarea class="form-control" name="comentario" rows="5" data-rule="required" data-msg="Por favor, escríbenos algo" placeholder="Mensaje"></textarea>
                            <div class="validation"></div>
                        </div>
                    </div>

                    <div class="col-xs-12">
                        <!-- Button -->
                        <button type="submit" id="enviarcomentario" name="enviarcomentario" class="form contact-form-button light-form-button oswald light">ENVIAR EMAIL</button>
                    </div>
                </form>

            </div>
        </div>
    </section>
    <!--/ Contacto-->
