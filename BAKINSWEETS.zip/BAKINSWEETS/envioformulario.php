<?php 
	// para que no dé error
	$mensaje="";
	if (isset($_REQUEST['enviarcomentario'])) {
		$email=$_REQUEST['email'];
		$nombre=$_REQUEST['nombre'];
		$asunto=$_REQUEST['asunto'];
		$comentario=htmlspecialchars($_REQUEST['comentario']);

		if ($email=="" OR $comentario=="") {
			$mensaje="<h2>No puedes enviar un comentario sin email o sin contenido</h2>";
			
		}else{
			$destinatario="enjoyjos@hotmail.com";
			// el origen es $email
			// el mensaje es $comentario
			
			$textoaenviar="
				<html>
					<head>
						<title>Correo enviado desde BakinSweets</title>
					</head>
					<body>
						<h1>$asunto</h1>
						<h2>Enviado por: $nombre</h2>
						<h3>Desde: $email</h3>
						<p>$comentario</p>
					</body>
					</html>";
			// Para enviar un correo HTML, debe establecerse la cabecera Content-type
			$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
			$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			// Cabeceras adicionales
			$cabeceras .= 'To: Jose <enjoyjos@hotmail.com>' . "\r\n";
			$cabeceras .= "From: $nombre <$email>" . "\r\n";		

			mail($destinatario,$asunto,$textoaenviar,$cabeceras);

			$mensaje="<h2>Su comentario ha sido enviado. En breve nos pondremos en contacto</h2>";
			
		}
		/*$_SESSION['mensaje']=$mensaje;
		header("Location: #contacto");*/
	}

 ?>