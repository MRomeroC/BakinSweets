
<section id="" class="section-padding">
    <div class="container cta-2-txt">
        <div class="row">
            <div class="header-section text-center">
				<h1>Desglose de su compra</h1>	
			</div>
<?php 
	$micarrito->verCarrito();

?>


</div>
<br>
<p><a href="bakinsweets.php?vaciar=ok" class="btn btn-danger btn-flat btn-tam">Vaciar carrito</a></p>

<p><a href="finalizarcompra.php" class="btn btn-danger btn-flat btn-tam">Finalizar compra</a></p>
</div>
</section>	