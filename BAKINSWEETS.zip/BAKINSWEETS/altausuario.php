<?php 

$mensaje="";
if (isset($_REQUEST['registrar'])) {
  $usuario=$_REQUEST['usuario'];
  $clave1=$_REQUEST['clave1'];
  $clave2=$_REQUEST['clave2'];
  $nombre=$_REQUEST['altanombre'];
  $apellidos=$_REQUEST['apellidos'];
  $direccion=$_REQUEST['direccion'];
  $ciudad=$_REQUEST['ciudad'];
  $cp=$_REQUEST['cp'];
  $provincia=$_REQUEST['provincia'];
  $telefono=$_REQUEST['telefono'];

  if ($usuario!="" AND $clave1!="" AND $clave1==$clave2) {
  	if (Usuarios::buscaUsuarioCorreo($usuario)) {
  	 $mensaje="El usuario ya existe, no se puede repetir.";
  	}else{
  	  Usuarios::altaUsuario($usuario,$nombre,$apellidos,$direccion,$ciudad,$cp,$provincia,$telefono,$clave1);
  	  $mensaje="Usuario dado de alta con éxito";
  	}
  }else{
  	$mensaje="Los campos no pueden ser vacíos y/o las claves no pueden ser diferentes";
  }
}
 ?>
<section id="altausuario" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>Regístrate en BakinSweets</h2>
                    <p>Completa el siguiente formulario para registrarte en BakinSweets. 
                      <br>
                    Guardaremos los datos que nos proporciones para facilitar tus compras a través de la web.</p>
                    <hr class="bottom-line">
                </div>
                <div><?=$mensaje ?></div>
                <div id="sendmessage"></div>
              <!--   <form action="indexaltausuario.php" method="get" role="form" class="contactForm"> -->
                  <form action="indexaltausuario.php" method="post" id="formulario" class="contactForm">
                  <div class="col-md-3 col-xs-12 left"></div>
                    <div class="col-md-6 col-xs-12 left">
                        <h2>Cuenta de usuario</h2>
                        <div class="form-group">
                            <input type="email" class="form-control" name="usuario" id="usuario" placeholder="Tu email" required />
                            <div class="validation">Introduce un email válido</div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave1" id="clave1" placeholder="Tu contraseña" required/>
                            <div class="validation">Introduce al menos 6 caracteres</div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave2" id="clave2" placeholder="Repite tu contraseña" required/>
                            <div class="validation">Introduce al menos 6 caracteres</div>
                        </div>
                        <h2>Datos de contacto</h2>
                        <div class="form-group">
                            <input type="text" name="altanombre" class="form-control form" id="altanombre" placeholder="Tu nombre"  />
                            <div class="validation">El nombre es obligatorio</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="apellidos" class="form-control form" id="apellidos" placeholder="Tus apellidos" required />
                            <div class="validation">El apellido es obligatorio</div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Dirección" required />
                            <div class="validation">La dirección es obligatoria</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="ciudad" class="form-control form" id="ciudad" placeholder="Tu ciudad" />
                            <div class="validation">La ciudad es obligatoria</div>
                        </div>
                        <div class="form-group">
                            <input type="number" name="cp" class="form-control form" id="cp" placeholder="Tu C.P." />
                            <div class="validation">Introduce al menos 5 dígitos</div>
                        </div>
                        <div class="form-group">
                            <select name="provincia" id="provincia" class="form-control form">
                              <option value="0">Seleccione una provincia</option>
                              <?php 
                                $datos=Usuarios::provincias();
                                foreach ($datos as $key => $value) {
                                  echo "<option value='".$value['idProvincia']."'>".$value['nombreProvincia']."</option>";
                                }
                              ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="number" name="telefono" class="form-control form" id="telefono" placeholder="Tu teléfono." />
                            <div class="validation">Introduce al menos 9 dígitos</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12"></div>
                    </div>
                    <div class="row">
                      <div class="col-md-3 col-xs-12"></div>
                      <div class="col-md-6 col-xs-12">
                        <!-- Button -->
                        <input type="submit" name="registrar" id="registrar" class="form contact-form-button light-form-button oswald light" value="DAR DE ALTA">

                      </div>
                      <div class="col-md-3 col-xs-12 left"></div>
                    </div>
                </form>
                <div class="row">
                  <div class="col-md-3 col-xs-12 left"></div>
                  <div class="col-md-6 col-xs-12">
                    <a class="centrar" href="bakinSweets.php">Ir a la tienda</a>
                  </div>
                  <div class="col-md-3 col-xs-12 left"></div>
                </div>
        </div>
    </section>
</body>
</html>
