<?php 

$mensaje="";
if (isset($_REQUEST['registrar'])) {
  $usuario=$_REQUEST['usuario'];
  $clave1=$_REQUEST['clave1'];
  $clave2=$_REQUEST['clave2'];
  $nombre=$_REQUEST['altanombre'];
  $apellidos=$_REQUEST['apellidos'];
  $direccion=$_REQUEST['direccion'];
  $ciudad=$_REQUEST['ciudad'];
  $cp=$_REQUEST['cp'];
  $provincia=$_REQUEST['provincia'];
  $telefono=$_REQUEST['telefono'];

  if ($usuario!="" AND $clave1!="" AND $clave1==$clave2) {
  	if (Usuarios::buscaUsuarioCorreo($usuario)) {
  	 $mensaje="El usuario ya existe, no se puede repetir.";
  	}else{
  	  Usuarios::altaUsuario($usuario,$nombre,$apellidos,$direccion,$ciudad,$cp,$provincia,$telefono,$clave1);
  	  $mensaje="Usuario dado de alta con éxito";
  	}
  }else{
  	$mensaje="Los campos no pueden ser vacíos y/o las claves no pueden ser diferentes";
  }
}
 ?>
 
    
<section id="altausuario" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>Regístrate en BakinSweets</h2>
                    <p>Completa el siguiente formulario para registrarte en BakinSweets. 
                      <br>
                    Guardaremos los datos que nos proporciones para facilitar tus compras a través de la web.</p>
                    <hr class="bottom-line">
                </div>
                <div class="text-center"><?=$mensaje ?></div>
              
                  <form action="indexaltausuario.php" method="post" id="formulario">
                  <div class="col-md-3 col-xs-12 left"></div>
                    <div class="col-md-6 col-xs-12 left">
                        <h2>Cuenta de usuario</h2>
                        <div class="form-group">
                            <input type="text" class="form-control" name="usuario" id="usuario" placeholder="Tu email"  />
                            <div class="validation" id="mensaje1">Introduce tu email</div>
                            <div class="validation" id="mensaje2">Introduce un email válido</div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave1" id="clave1" placeholder="Tu contraseña" />
                            <div class="validation" id="mensaje3">Introduce al menos 6 caracteres</div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave2" id="clave2" placeholder="Repite tu contraseña" />
                            <div class="validation" id="mensaje4">Introduce al menos 6 caracteres</div>
                            <div class="validation" id="mensaje5">La contraseña no coincide</div>
                        </div>
                        <h2>Datos de contacto</h2>
                        <div class="form-group">
                            <input type="text" name="altanombre" class="form-control form" id="altanombre" placeholder="Tu nombre"  />
                            <div class="validation" id="mensaje6">El nombre es obligatorio</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="apellidos" class="form-control form" id="apellidos" placeholder="Tus apellidos"  />
                            <div class="validation" id="mensaje7">El apellido es obligatorio</div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Dirección"  />
                            <div class="validation" id="mensaje8">La dirección es obligatoria</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="ciudad" class="form-control form" id="ciudad" placeholder="Tu ciudad" />
                            <div class="validation" id="mensaje9">La ciudad es obligatoria</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="cp" class="form-control form" id="cp" placeholder="Tu C.P." />
                            <div class="validation" id="mensaje10">Introduce el CP</div>
                            <div class="validation" id="mensaje11">Introduce los 5 dígitos de tu CP</div>
                        </div>
                        <div class="form-group">
                            <select name="provincia" id="provincia" class="form-control form">
                              <option value="0">Seleccione una provincia</option>
                              <?php 
                                $datos=Usuarios::provincias();
                                foreach ($datos as $key => $value) {
                                  echo "<option value='".$value['idProvincia']."'>".$value['nombreProvincia']."</option>";
                                }

                              ?>
                            </select>
                            <div class="validation" id="mensaje12">Seleccione una provincia</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="telefono" class="form-control form" id="telefono" placeholder="Tu teléfono." />
                            <div class="validation" id="mensaje13">Introduce un teléfono</div>
                            <div class="validation" id="mensaje14">Introduce al menos 9 dígitos</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12"></div>
                    </div>
                    <div class="row">
                      <div class="col-md-3 col-xs-12"></div>
                      <div class="col-md-6 col-xs-12">
                        <!-- Button -->
                        <input type="submit" name="registrar" id="registrar" class="form contact-form-button light-form-button oswald light" value="DAR DE ALTA">

                      </div>
                      <div class="col-md-3 col-xs-12 left"></div>
                    </div>
                </form>
                <div class="row">
                  <div class="col-md-3 col-xs-12 left"></div>
                  <div class="col-md-6 col-xs-12">
                    <a class="centrar" href="bakinSweets.php">Ir a la tienda</a>
                  </div>
                  <div class="col-md-3 col-xs-12 left"></div>
                </div>
        </div>
    </section>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="contactform/validacion.js"></script>
