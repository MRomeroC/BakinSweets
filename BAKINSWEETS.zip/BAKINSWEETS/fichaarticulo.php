<?php 


	$idArticulo=$_REQUEST['idArticulo'];
include_once "clases.php";
	$datos=Articulos::datosArticulo($idArticulo);


 ?>
<section id="" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
  <h2><?=$datos['nombreArticulo']?></h2>
  <h3><?=$datos['nombreCategoria']?></h3>
  <h4><?=$datos['nombreSubcat']?></h4>
              </div>
          <div class="row cta-2-txt"">
                   
                <p><img src='imagenes/<?=$datos['foto']?>' alt='<?=$datos['nombreArticulo']?>' width='385'> </p>
                <p><?=$datos['descripcion']?> </p>
                <p>Precio: <?=$datos['precio']?>€</p>  
                <p>Stock: <?=$datos['stock']?></p>
                <h3><a href="indexarticulo.php?idArticulo=<?=$datos['idArticulo']?>&alcarrito=ok"><i class='fas fa-cart-plus'></i></a></h3> 

                <p class="text-left"><a href="bakinSweets.php">Ir a la página principal</a></p>       
          </div>
        </div>
      </div>
 	
 </section>
 

