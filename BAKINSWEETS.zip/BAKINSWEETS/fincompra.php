<?php 

if (isset($_SERVER['HTTPS'])) {
	$servidor="https://".$_SERVER['HTTP_HOST']."/";
} else {
	$servidor="http://".$_SERVER['HTTP_HOST']."/Curso2018/Proyecto/BAKINSWEETS/";
}

?>


<section id="" class="section-padding">
    <div class="container cta-2-txt">
        <div class="row">
            <div class="header-section text-center">
		<h1>Resumen de la compra</h1>	
			</div>

<?php 
echo "$mensaje";
if ($misesion->estadoLogin()) {
	//permitimos mostrar el resumen del carrito y realizar la compra

?>

<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
	<input type="hidden" name="cmd" value="_cart">
	<input type="hidden" name="upload" value="1">
	<!--dirección de correo del vendedor-->
	<input type="hidden" name="business" value="cuentainventada@gmail.com">
	<!--url de la página web-->
	<input type="hidden" name="shopping_url" value="<?=$servidor ?>">
	<!--dirección de mi sitio web una vez hecho el pago-->
	<input type="hidden" name="return" value="<?=$servidor ?>finalizarCompra.php?codigo=555">
	<!--dirección de mi sitio web si falla el pago-->
	<input type="hidden" name="cancel_return" value="<?=$servidor ?>finalizarCompra.php?codigo=666">
	<!--definir el tipo de moneda-->
	<input type="hidden" name="currency_code" value="EUR">
	
<?php 
	$micarrito->resumenCarrito();

?>
	<input type="image" src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/cc-badges-ppppcmcvdam.png" name="submit" boder="0" alt="Paypal. La forma más segura de comprar y vender.">
	
	</form>
<?php 

} else{


?>

<hr>
<p>Para poder realizar el pago, debe estar regitrado en nuestra web.</p>
<p>Puede registrarse en este <a href="indexaltausuario.php">enlace</a></p>
<p>Si ya está registrado, acceda desde la parte superior de la web.</p>

<?php  } ?>



</div>
</div>

</section>	