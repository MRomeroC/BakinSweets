<?php
	$idUsuario=$misesion->getidUsuario(); 
	$datos=Pedidos::muestraPedidos($idUsuario);
?>

<section id="" class="section-padding">
    <div class="container">
        <div class="row">
            <div class="header-section text-center">
            	<h2>Mis compras</h2>
            	<hr>
            </div>
			<div class="cta-2-txt">
				<div>
					<h3><a href="indexmodificaUsuario.php?idUsuario=<?=$idUsuario ?>">Mis datos de usuario</a></h3>
					<br>
					
					<table class="tablaPedidos">
						<caption><h3>Mis pedidos</h3></caption>
						<thead>
							<tr>
							<th>Nº Pedido</th>
							<th>Fecha</th>
							<th>Total</th>
							<th></th>
							<th></th>
							</tr>
						</thead>
						<tbody>
					
	<?php 
	foreach ($datos as $key => $value) {
		$idPedido=$value['idPedido'];
		echo "<tr>
		<td>$idPedido</td>
		<td>".$value['fechaPedido']."</td>
		<td>".$value['totalPedido']."</td>
		<td><a href='indexfichaPedido.php?idPedido=".$value['idPedido']."' class='btn btn-default btn-green btn-xs text-uppercase'>Ver pedido</a></td>
		<td><a href='listadopdf.php?idPedido=$idPedido&idUsuario=$idUsuario' target='_blank'class='btn btn-default btn-green btn-xs text-uppercase'>Imprimir pedido</a></td>
		</tr>";
	}
	?>
				</tbody>
				</table>
				</div>

			</div>
			<a href="index.php">Volver a la página principal</a>
        </div>
    </div>
</section>