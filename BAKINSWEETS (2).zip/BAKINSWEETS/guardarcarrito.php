<?php 
$mensaje="";
if (isset($_REQUEST['codigo'])) {
	if ($_REQUEST['codigo']==555 AND !empty($_SESSION['carrito'])) {
	//almacenar el carrios en la bbdd
		$idUsuario=Usuarios::getIdUsuario($_SESSION['usuario']);
		$fechaPedido=date("Y-m-d");
		$horaPedido=date("H:i:s");
		$totalPedido=$micarrito->getImporteTotal();

		//Alta del pedido
		$idPedido=Pedidos::altaPedido($idUsuario,$fechaPedido,$horaPedido,$totalPedido);

		//Alta Lineas del Pedido
		foreach ($_SESSION['carrito'] as $key => $value) {
			if ($key!='precioTotal' AND $key!='articulosTotal') {
				$idArticulo=$key;
				$cantidad=$value['cantidad'];
				$precio=$value['precio'];

				LineasPedidos::altaLineaPedido($idPedido,$idArticulo,$cantidad,$precio);
				$datos=Articulos::datosArticulo($idArticulo);
				$stock=$datos['stock'];
				Articulos::actualizarStock($idArticulo,$stock,$cantidad);
			}
		} //fin alta Lineas de Pedido

		$micarrito->vaciarCarrito();
		$micarrito=new Carrito();
		


		$mensaje="<h3>El pedido ha sido realizado con éxito</h3><h4>Será entregado en la dirección proporcionada</h4><br>";
	}
	if ($_REQUEST['codigo']==666) {
		$mensaje="<h3>El pedido no se ha podido pagar correctamente</h3><h4>Repita el proceso más tarde o póngase en contacto con su administrador</h4><br>";

	}

}

?>