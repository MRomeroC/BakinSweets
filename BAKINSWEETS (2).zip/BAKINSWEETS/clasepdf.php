<?php 
include_once "fpdf/fpdf.php";
class PDF extends FPDF{
/*function Header(){
    // Select Arial bold 15
    $this->SetFont('Arial','B',20);
    // Move to the right
    //$this->Cell(80,10,"Logo");
    //ruta, x, y, altura, ancho, los dos últimos parámetros no son necesarios
    $this->Image('img/logo.png',3,7,100,18,'PNG','$servidor/bakinsweets.php');
    // Line break
    $this->Ln(20);
}*/



function Footer(){
    // Go to 1.5 cm from bottom
    $this->SetY(-15);
    $this->SetTextColor(92,51,23);
    // Select Arial italic 8
    $this->SetFont('Arial','I',8);
    // Print centered page number
    $this->Cell(0,10,utf8_decode('Página ').$this->PageNo(),0,0,'C');
}
}

?>