<?php 

if (isset($_REQUEST['modificaArticulo'])) {
	$idArticulo=$_REQUEST['idArticulo'];
	$idSubcat=$_REQUEST['idSubcat'];
	$nombreArticulo=$_REQUEST['nombreArticulo'];
	$descripcion=$_REQUEST['descripcion'];
	$precio=$_REQUEST['precio'];
  $stock=$_REQUEST['stock'];

	if ($_FILES['foto']['name']!="") {
		if ($_FILES['foto']['error']>0) {
		echo "ERROR: Archivo no válido.<br>";
	} else {
//es mejor meterlo en un archivo nuevo y usar un include_once
		$tipo=$_FILES['foto']['type'];
		$tamFile=$_FILES['foto']['size'];

		if ($tipo=="image/jpeg" || $tipo=="image/png" || $tipo=="image/gif" || $tipo=="image/bmp" && $tamFile<1000000) {
			$destino="../imagenes/".$_FILES['foto']['name'];

			copy($_FILES['foto']['tmp_name'], $destino);
			Articulos::actualizaArticulo($idArticulo,$idSubcat,$nombreArticulo,$descripcion,$precio,$stock,$destino);
  			echo "<h2>Se ha modificado el artículo $nombreArticulo</h2>";

		} else {
			echo "ERROR: No admitimos ese tipo de archivo<br>";
		}
	}
	} else {
		Articulos::actualizaArticulo($idArticulo,$idSubcat,$nombreArticulo,$descripcion,$precio,$stock);
	}


	

}


if (isset($_REQUEST['borrarArticulo']))
{
  $idArticulo=$_REQUEST['idArticulo'];
  Articulos::eliminarArticulo($idArticulo);
}

$listado=Articulos::listadoArticulos();

?>

<h2>Listado de Artículos</h2>
 <table>
 	<tr>
    	<th>Categoría</th>
 		<th>Subcategoría</th>
		<th>Artículo</th>
		<th>Stock</th>
 		<th> </th>
 		<th> </th>
 	</tr>
<?php 
foreach ($listado as $indice => $valor)
{
  echo "<tr>";
  echo "<td>".$valor['nombreCategoria']."</td>";
  echo "<td>".$valor['nombreSubcat']."</td>";
  echo "<td>".$valor['nombreArticulo']."</td>";
  echo "<td>".$valor['stock']."</td>";
  echo "<td><a href='admin.php?menu=33&idArticulo=".$valor['idArticulo']."&verArticulo=ok' >ver</a></td>";
  echo "<td><a href='admin.php?menu=31&idArticulo=".$valor['idArticulo']."&borrarArticulo=ok' >eliminar</a></td>";
  echo "<td><a href='admin.php?menu=34&idArticulo=".$valor['idArticulo']."&modificaArticulo=ok' >modificar</a></td>";
  echo "</tr>";
}
 ?> 	
 </table>

 <hr>
 <a href="index.php">Ir al menú principal</a>









<?php 
/*
if (isset($_REQUEST['modificaSubcat'])){
  $idSubcat=$_REQUEST['idSubcat'];
  $idCategoria=$_REQUEST['idCategoria'];
  $nombreSubcat=$_REQUEST['nombreSubcat'];
  $descripcionsubcat=$_REQUEST['descripcionsubcat'];

Subcategorias::actualizaSubcat($idSubcat,$nombreSubcat,$descripcionsubcat,$idCategoria);

}


if (isset($_REQUEST['borrarSubcat']))
{
  $idSubcat=$_REQUEST['idSubcat'];
  Subcategorias::eliminarSubcat($idSubcat);
}

if (isset($_REQUEST['modificaCat'])) {
  $idCategoria=$_REQUEST['idCategoria'];
  $nombreCategoria=$_REQUEST['nombreCategoria'];
  $descripcionCat=$_REQUEST['descripcionCat'];
  Categorias::modificaCategoria($idCategoria,$nombreCategoria,$descripcionCat);

}

if (isset($_REQUEST['idCategoria'])) {
  $idCategoria=$_REQUEST['idCategoria'];
  $listado=Subcategorias::listadoSubcategorias($idCategoria);
}else{
  $listado=Subcategorias::listadoSubcategorias();
}
*/
 ?>
