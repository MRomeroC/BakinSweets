<?php 

$listado=array();

if (isset($_REQUEST['buscarpedidos'])) {
	$nombre=$_REQUEST['nombre'];
	$fechaPedido=$_REQUEST['fechaPedido'];


	if ($nombre=="" && $fechaPedido=="") {
		$listado=Pedidos::buscarPedidos();
	} else{
		$listado=Pedidos::buscarPedidos($nombre, $fechaPedido);
	}



}


?>




<h2>Búsqueda de Artículos</h2>
<form action="admin.php" method="post">
	<input type="hidden" name="menu" value="41">
	<label for="nombre">Nombre Cliente: </label>
	<input type="text" name="nombre" placeholder="Nombre completo o parte de él">
	<br>
	<label for="fechaPedido">Fecha del Pedido</label>
	<input type="date" name="fechaPedido">
	<br>
	<input type="submit" name="buscarpedidos" value="Buscar Pedidos">
</form>
<hr>
<h2>Resultado de la búsqueda</h2>
<table>
 	<tr>
    	<th>Nº Pedido</th>
 		<th>Fecha</th>
		<th>Cliente</th>
		<th>Total</th>
		<th> </th>
 	</tr>
<?php 
foreach ($listado as $indice => $valor)
{
$idUsuario=$valor['idUsuario'];
  echo "<tr>";
  echo "<td>".$valor['idPedido']."</td>";
  echo "<td>".$valor['fechaPedido']."</td>";
  echo "<td>".$valor['nombre']."</td>";
  echo "<td>".$valor['totalPedido']."</td>";
  echo "<td><a href='verpedido.php?idPedido=".$valor['idPedido']."'>Ver pedido</a></td>
  <td><a href='../listadopdf.php?idPedido=".$valor['idPedido']."&idUsuario=$idUsuario' target='_blank'class='btn btn-default btn-green btn-xs text-uppercase'>Imprimir pedido</a></td>";
  
  echo "</tr>";
}
 ?> 	
 </table>
 <hr>
 <a href="index.php">Ir al menú principal</a>