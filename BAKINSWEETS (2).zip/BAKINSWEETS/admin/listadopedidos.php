<?php 

$listado=Pedidos::listadoPedidos();
 ?>

 <h2>Listado de pepidos</h2>
 <table class="tablaPedidos">
 	<tr>
 		<th>idPedido</th>
 		<th>Cliente</th>
 		<th>Fecha</th>
		<th>Total</th>
    	<th></th>
    	<th></th>
 	</tr>
<?php 
foreach ($listado as $indice => $valor)
{
	$idUsuario=$valor['idUsuario'];
  echo "<tr>";
  echo "<td>".$valor['idPedido']."</td>";
  echo "<td>".$valor['nombre']."</td>";
  echo "<td>".$valor['fechaPedido']."</td>";
  echo "<td>".$valor['totalPedido']."</td>";
  echo "<td><a href='verpedido.php?idPedido=".$valor['idPedido']."'>Ver pedido</a></td>
  <td><a href='../listadopdf.php?idPedido=".$valor['idPedido']."&idUsuario=$idUsuario' target='_blank'class='btn btn-default btn-green btn-xs text-uppercase'>Imprimir pedido</a></td>";
  echo "</tr>";
}
 ?> 	
 </table>

 <hr>
 <a href="index.php">Ir al menú principal</a>