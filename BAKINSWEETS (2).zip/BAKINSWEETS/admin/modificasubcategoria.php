<?php 

$idSubcat = $_REQUEST['idSubcat'];


$datos = Subcategorias::datosSubcategoria($idSubcat);

$listado=Categorias::listadoCategorias();

 ?>
<h2>Modificar Subcategoría</h2>
<form action="admin.php" method="post">
	<input type="hidden" name="menu" value="21">
	<input type="hidden" name="idSubcat" value="<?=$idSubcat?>">	
	<label for="idCategoria">Categoría: </label>
  <select name="idCategoria">
  <?php 
  foreach ($listado as $indice=>$valor)
  {
  	if ($valor["idCategoria"]==$datos["idCategoria"]) {
  		echo "<option value='".$valor['idCategoria']."' selected> ".$valor['nombreCategoria']." </option>";
  	} else{
  	echo "<option value='".$valor['idCategoria']."'> ".$valor['nombreCategoria']." </option>";
  }
  }
   ?>
   </select>
  <br>
  <label for="nombreSubcat">Nombre Subcategoría: </label>
  <input type="text" name="nombreSubcat" value="<?=$datos['nombreSubcat']?>"> <br>
  <label for="descripcionSubcat">Descripción Subcategoría:</label>
  <br>
  <textarea name="descripcionsubcat" cols="30" rows="10"><?=$datos["descripcionSubcat"]?></textarea><br>
  <input type="submit" name="modificaSubcat" value="Modificar">
</form>
<hr>
<a href="index.php">Ir al menú principal</a>