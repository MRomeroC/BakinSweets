<?php 
	// para que no dé error
	$mensaje="";
	if (isset($_REQUEST['enviarNews'])) {
		$asunto=$_REQUEST['asunto'];
		$comentario=htmlspecialchars($_REQUEST['comentario']);

		if ($asunto=="" OR $comentario=="") {
			$mensaje="<h2>No puedes enviar un comentario sin asunto o sin contenido</h2>";
			
		}else{
			
			$textoaenviar="
				<html>
					<head>
						<title>Correo enviado desde BakinSweets</title>
					</head>
					<body>
						<h1>$asunto</h1>
						<h2>Enviado por: BakinSweets</h2>
						<p>$comentario</p>
					</body>
					</html>";
			// Para enviar un correo HTML, debe establecerse la cabecera Content-type
			$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
			$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			// Cabeceras adicionales
			$cabeceras .= "Cco: ";
				$listanews=Newsletter::listadoNews();
				foreach ($listanews as $key => $value) {
					$cabeceras.=$value['email'].", ";
				}
				
			}		

			mail($asunto,$textoaenviar,$cabeceras);

			$mensaje="<h2>La newsletter ha sido enviada.</h2>";
			
		}
		

 ?>

<h2>Enviar Newsletter</h2>
<form action="admin.php" method="post" style='width: 40%; margin: auto;'>
	<input type="hidden" name="menu" value="50">
	<input type="text" name="asunto" placeholder="Asunto"  style='width: 100%; margin: auto;'>
	<br><br>
	<textarea name="comentario" cols="50" rows="10"  style='width: 100%; margin: auto;' placeholder="Escribe aquí tu newsletter"></textarea>
	<br>
	<input type="submit" name="enviarNews" value="Enviar Newsletter">
</form>
<hr>
<a href="index.php">Ir al menú principal</a>

