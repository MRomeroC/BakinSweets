<!-- <?php 
//$idSubcat=$_REQUEST['idSubcat'];
//$idCategoria=$_REQUEST['idCategoria'];
//$posicion=$_REQUEST['posicion'];
//$articulosPorPagina=$_REQUEST['articulosPorPagina'];
$listado=Articulos::listadoArticulos(0, 0, $idSubcat, $idCategoria);    
$datos=Subcategorias::datosCategoriaSubcat($idSubcat);


?> -->




<section id="cta-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="text-center">Suscríbete a nuestra Newsletter</h2>
                    <p class="cta-2-txt">Apúntate a nuestra newsletter para recibir un email semanal y mantenerte al tanto de las últimas noticias y talleres de pastelería.</p>
                    <div class="cta-2-form text-center">
                        <form action="index.php" method="post" id="newsletter">
                            <input name="emailNewsletter" placeholder="Introduce tu email" type="email">
                            <input class="cta-2-form-submit-btn" name="altaNewsletter" value="Suscríbete" type="submit">
                        </form>
                    </div>
                    <br>
                    <div class="col-lg-12">
                    <p class="cta-2-txt"><?=$mensajeNews ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ Cta-->
    <!--pasteleria-->
    <section id="pasteleria" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>La Pastelería</h2>
                    <p>Ven a visitar nuestra pastelería, todo un deleite para los sentidos. </p>
                    <p>Especialistas en los siguientes productos:</p>
                    <hr class="bottom-line">
                </div>
                <div class="feature-info">
                    <div class="fea">
                        <div class="col-md-4">
                            <div class="heading pull-right">
                                <h4>Cupcakes</h4>
                                <p>Nuestros cupcakes favoritos son Guinness, Red Velvet, Devil's Food, Zanahoria, Tiramisú. Querrás probarlos todos.</p>
                            </div>
                            <div class="fea-img pull-left">
                                <i class="fas fa-chess-queen"></i>
                            </div>
                        </div>
                    </div>
                    <div class="fea">
                        <div class="col-md-4">
                            <div class="heading pull-right">
                                <h4>Galletas</h4>
                                <p>Porque en la variedad está el gusto: Doble chocolate, limón, crema de cacahuete, nutella, mantequilla, pasas y muchas más.</p>
                            </div>
                            <div class="fea-img pull-left">
                                <i class="fas fa-bowling-ball"></i>
                            </div>
                        </div>
                    </div>
                    <div class="fea">
                        <div class="col-md-4">
                            <div class="heading pull-right">
                                <h4>Tartas</h4>
                                <p>Ideales para un evento especial. Disponemos de varios tamaños y se pueden personalizar. Recomendamos Guinness, Red Velvet, Devil's Food y Calabaza.</p>
                            </div>
                            <div class="fea-img pull-left">
                                <i class="fas fa-birthday-cake"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ pasteleria-->
    <!--estadistica-->
    <section id="estadistica" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div class="orga-stru">
                            <h3>99%</h3>
                            <p>Dicen que sí!!</p>
                            <i class="fa fa-male"></i>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div class="orga-stru">
                            <h3>0.1%</h3>
                            <p>Dicen que no!!</p>
                            <i class="fa fa-male"></i>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div class="orga-stru">
                            <h3>0.9%</h3>
                            <p>Todavía no los probaron!!</p>
                            <i class="fa fa-male"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="detail-info">
                        <hgroup>
                            <h3 class="det-txt"> ¿Os gustan nuestros postres?</h3>
                            <h4 class="sm-txt">(Opiniones de nuestros clientes)</h4>
                        </hgroup>
                        <p class="det-p">Hemos preguntado a nuestros clientes qué opinan sobre nuestros dulces y las estadística lo deja muy claro.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ estadistica-->
    <!--reposteros-->
    <!--reposteros-->
    <section id="reposteros" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>Conócenos</h2>
                    <p>Conoce a los mejores reposteros que conforman nuestro equipo. </p>
                    <hr class="bottom-line">
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="pm-staff-profile-container">
                        <div class="pm-staff-profile-image-wrapper text-center">
                            <div class="pm-staff-profile-image">
                                <img src="img/nick-karvounis-624439-unsplash.jpg" alt="" class="img-thumbnail img-circle" />
                            </div>
                        </div>
                        <div class="pm-staff-profile-details text-center">
                            <p class="pm-staff-profile-name">José Palacio</p>
                            <p class="pm-staff-profile-title">Repostero jefe</p>

                            <p class="pm-staff-profile-bio">Reconocido repostero, se formó en la Escuela de Hostelería AIALA del prestigioso Karlos Arguiñano. Tiene una trayectoria profesional que excede los 20 años de experiencia.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="pm-staff-profile-container">
                        <div class="pm-staff-profile-image-wrapper text-center">
                            <div class="pm-staff-profile-image">
                                <img src="img/roman-kraft-56589-unsplash.jpg" alt="" class="img-thumbnail img-circle" />
                            </div>
                        </div>
                        <div class="pm-staff-profile-details text-center">
                            <p class="pm-staff-profile-name">Mónica Romero</p>
                            <p class="pm-staff-profile-title">Pastelera de vocación</p>

                            <p class="pm-staff-profile-bio">Nuestra pastelera más golosa se graduó Suma Cum Laude en la Escuela de Hostelería de París, con la especialidad en chocolate.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="pm-staff-profile-container">
                        <div class="pm-staff-profile-image-wrapper text-center">
                            <div class="pm-staff-profile-image">
                                <img src="img/travis-grossen-552169-unsplash.jpg" alt="" class="img-thumbnail img-circle" />
                            </div>
                        </div>
                        <div class="pm-staff-profile-details text-center">
                            <p class="pm-staff-profile-name">Yvan Drago</p>
                            <p class="pm-staff-profile-title">Commis Chef</p>

                            <p class="pm-staff-profile-bio">La nueva adquisición de nuestro equipo promete mucho, te sorprenderán sus innovadoras creaciones. Un toque de aire fresco llegado desde Dubrovnik. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ reposteros-->
    <!--Testimonial-->
    <section id="testimonial" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2 class="white">Mira lo que nuestros clientes comentan</h2>
                    <p class="white">Las opiniones de nuestros clientes son nuestra mejor garantía. <br>Aquí tienes una muestra de sus comentarios.</p>
                    <hr class="bottom-line bg-white">
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="text-comment">
                        <p class="text-par">"Increíbles pasteles que te endulzan hasta el día más amargo"</p>
                        <p class="text-name">Amparo García - Clienta habitual</p>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="text-comment">
                        <p class="text-par">"Nunca te cansarás de los dulces de esta pastelería, siempre tienen algo nuevo que probar"</p>
                        <p class="text-name">Karlos Arguiñano - Experto catador</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ Testimonial-->

 <!--/ Dulces-->
<section id="dulces" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>Nuestros dulces</h2>
                    <hr class="bottom-line">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
<?php 	
	$i=0;	
    $total= count($listado)-1;
    $losqueyasalieron=array();


    for ($i=0; $i < 6; $i++) {

        $aleatorio=rand(0, $total);
        while (in_array($aleatorio, $losqueyasalieron)) {
            $aleatorio=rand(0, $total);
        }
        $losqueyasalieron[]=$aleatorio;

        echo "<div class='col-md-4 col-sm-6 padleft-right'>
                    <figure class='imghvr-fold-up'>
                        <img src='imagenes/".$listado[$aleatorio]['foto']."' class='img-responsive'>
                        <figcaption>
                            <h3>".$listado[$aleatorio]['nombreArticulo']."</h3>
                            <p>".$listado[$aleatorio]['descripcion']."</p>
                            <h4>".$listado[$aleatorio]['precio']."€</h4>
                            <a href='indexarticulo.php?idArticulo=".$listado[$aleatorio]['idArticulo']."'></a>
                        </figcaption>
                        
                    </figure>
                </div>";
    
        if ($i%3==0) {
    		echo "<div class='clearfix visible-md'></div>";
    		
    	}            
    }
          
                
                
 ?>   
            </div>
        </div>
    </section>
