<?php 
$idUsuario=$_REQUEST['idUsuario'];
$listado=Usuarios::datosUsuario($idUsuario);

$mensaje="";
if (isset($_REQUEST['modificar'])) {
  $clave1=$_REQUEST['clave1'];
  $clave2=$_REQUEST['clave2'];
  $nombre=$_REQUEST['altanombre'];
  $apellidos=$_REQUEST['apellidos'];
  $direccion=$_REQUEST['direccion'];
  $ciudad=$_REQUEST['ciudad'];
  $cp=$_REQUEST['cp'];
  $idProvincia=$_REQUEST['provincia'];
  $telefono=$_REQUEST['telefono'];

  if ($clave1==$clave2) {
  	  Usuarios::actualizaUsuario($nombre,$apellidos,$direccion,$ciudad,$cp,$idProvincia,$telefono,$clave1, $idUsuario);
  	  $mensaje="Usuario actualizado con éxito";
  	
  }else{
  	$mensaje="Las claves no pueden ser diferentes";
  }
}
 ?>
 
    
<section id="modificaUsuario" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>Actualiza tus datos</h2>
                    <hr class="bottom-line">
                </div>
                <div class="text-center"><?=$mensaje ?></div>
              
                  <form action="indexmodificaUsuario.php" method="post" id="formulario">
                  <div class="col-md-3 col-xs-12 left"></div>
                    <div class="col-md-6 col-xs-12 left">
                        <h2>Cuenta de usuario</h2>
                        <p>Si quieres cambiar la contraseña:</p>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave1" id="clave1" placeholder="Introduce tu nueva contraseña" />
                            <div class="validation" id="mensaje3">Introduce al menos 6 caracteres</div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave2" id="clave2" placeholder="Repite tu contraseña" />
                            <div class="validation" id="mensaje5">La contraseña no coincide</div>
                        </div>
                        <h2>Datos de contacto</h2>
                        <input type="hidden" name="idUsuario" value="<?=$idUsuario ?>">
                        <div class="form-group">
                            <input type="text" name="altanombre" class="form-control form" id="altanombre" value="<?=$listado['nombre']?>" />
                            <div class="validation" id="mensaje6">El nombre es obligatorio</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="apellidos" class="form-control form" id="apellidos" value="<?=$listado['apellidos']?>" />
                            <div class="validation" id="mensaje7">El apellido es obligatorio</div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="direccion" id="direccion" value="<?=$listado['direccion']?>" />
                            <div class="validation" id="mensaje8">La dirección es obligatoria</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="ciudad" class="form-control form" id="ciudad"  value="<?=$listado['ciudad']?>" />
                            <div class="validation" id="mensaje9">La ciudad es obligatoria</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="cp" class="form-control form" id="cp"  value="<?=$listado['cp']?>" />
                            <div class="validation" id="mensaje10">Introduce el CP</div>
                            <div class="validation" id="mensaje11">Introduce los 5 dígitos de tu CP</div>
                        </div>
                        <div class="form-group">
                            <select name="provincia" id="provincia" class="form-control form">
                              <option value="0">Seleccione una provincia</option>
                              <?php 
                                $datos=Usuarios::provincias();
                                foreach ($datos as $key => $value) {
                                  if ($value['idProvincia']==$listado['idProvincia']) {
                                    echo "<option value='".$value['idProvincia']."' selected>".$value['nombreProvincia']."</option>";
                                  } else {
                                  echo "<option value='".$value['idProvincia']."'>".$value['nombreProvincia']."</option>";
                                  }
                                }

                              ?>
                            </select>
                            <div class="validation" id="mensaje12">Seleccione una provincia</div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="telefono" class="form-control form" id="telefono" value="<?=$listado['telefono']?>" />
                            <div class="validation" id="mensaje13">Introduce un teléfono</div>
                            <div class="validation" id="mensaje14">Introduce al menos 9 dígitos</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12"></div>
                    </div>
                    <div class="row">
                      <div class="col-md-3 col-xs-12"></div>
                      <div class="col-md-6 col-xs-12">
                        <!-- Button -->
                        <input type="submit" name="modificar" id="modificar" class="form contact-form-button light-form-button oswald light" value="ACTUALIZAR">

                      </div>
                      <div class="col-md-3 col-xs-12 left"></div>
                    </div>
                </form>
                <div class="row">
                  <div class="col-md-3 col-xs-12 left"></div>
                  <div class="col-md-6 col-xs-12">
                    <a href="indexparteusuario.php">Volver a mi perfil</a>
                  </div>
                  <div class="col-md-3 col-xs-12 left"></div>
                </div>
        </div>
    </section>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>