<nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
                <a class="navbar-brand" href="index.html">Bakin<span>Sweets</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#feature">La pastelería</a></li>
                    <li><a href="#organisations">Nuestros reposteros</a></li>
                    <li><a href="#courses">Nuestros dulces</a></li>
                    <li><a href="#contact">Contáctanos</a></li>
                </ul>
            </div>
        </div>
    </nav>