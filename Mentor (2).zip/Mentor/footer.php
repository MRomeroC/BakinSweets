<!--Footer-->
    <footer id="footer" class="footer">
        <div class="container text-center">
            <!-- End newsletter-form -->
            <ul class="social-links">
                <li><a href="#link"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#link"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#link"><i class="fab fa-instagram"></i></a></li>
                <li><a href="#link"><i class="fab fa-pinterest"></i></a></li>
                <li><a href="#link"><i class="fab fa-linkedin-in"></i></a></li>
            </ul>
            ©2018 BakinSweets. Todos los derechos reservados.
            <div class="credits">
                <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Mentor
        -->
                Diseñado por <a href="https://bootstrapmade.com/">BootstrapMade.com</a> y personalizada por Joyjos y MRomero.
            </div>
        </div>
    </footer>
    <!--/ Footer-->

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>