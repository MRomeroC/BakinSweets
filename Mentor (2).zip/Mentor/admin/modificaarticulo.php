<?php 

	$listado=Subcategorias::listadoSubcategorias();
	$idArticulo=$_REQUEST['idArticulo'];
	$datos=Articulos::datosArticulo($idArticulo);




?>


<h2>Modificar Artículo</h2>
<form action="admin.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="menu" value="31">
	<input type="hidden" name="idArticulo" value="<?=$datos['idArticulo']?>">
	<label for="idSubcat">Subcategoría: </label>
  <select name="idSubcat">
  <?php 
  foreach ($listado as $indice=>$valor){
  	if ($valor["idSubcat"]==$datos["idSubcat"]) {
  		echo "<option value='".$valor['idSubcat']."' selected>".$valor['nombreCategoria']." - ".$valor['nombreSubcat']." </option>";
  	} else {
  	echo "<option value='".$valor['idSubcat']."'>".$valor['nombreCategoria']." - ".$valor['nombreSubcat']." </option>";
  }
}
   ?>
   </select>
  <br>
	<label for="nombreArticulo">Nombre de Artículo: </label>
	<input type="text" name="nombreArticulo" value="<?=$datos['nombreArticulo']?>">
	<br>
	<label for="descripcion">Descripcion del artículo:</label>
	<br>
	<textarea name="descripcion" cols="30" rows="10"><?=$datos['descripcion']?></textarea>
	<br>
	<label for="precio">Precio: </label>
	<input type="text" name="precio" value="<?=$datos['precio']?>"> €
	<br>
	<label for="stock">Stock: </label>
	<input type="number" name="stock" value="<?=$datos['stock']?>">
	<br>
	<img src="<?=$datos['fotoArticulo']?>" alt="<?=$datos['nombreArticulo']?>" width="100px">
	<br>
	<label for="foto">Foto: </label>	
	<input type="file" name="foto">
	<br>
  <input type="submit" name="modificaArticulo" value="Modificar">
</form>
<hr>
<a href="listadoarticulos.php">Ir al menu principal</a>
