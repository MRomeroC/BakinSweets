<?php
include_once "head.php";
include_once "nav.php";

    
?>
