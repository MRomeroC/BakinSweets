<?php 

$listado=Subcategorias::listadoSubcategorias();
 
if (isset($_REQUEST['altaArticulo'])) {
  
  $idSubcat=$_REQUEST['idSubcat'];
  $nombreArticulo=$_REQUEST['nombreArticulo'];
  $descripcion=htmlspecialchars($_REQUEST['descripcion']);
  $precio=$_REQUEST['precio'];
  $stock=$_REQUEST['stock'];
  $datosCategoria=Subcategorias::datosCategoriaSubcat($idSubcat);
  $nombreCategoria=$datosCategoria['nombreCategoria'];

  if ($_FILES['foto']['error']>0) {
		echo "ERROR: Archivo no válido.<br>";
	} else {

		$tipo=$_FILES['foto']['type'];
		$tamFile=$_FILES['foto']['size'];

		if ($tipo=="image/jpeg" || $tipo=="image/png" || $tipo=="image/gif" || $tipo=="image/bmp" && $tamFile<1000000) {		

			$idArticuloNuevo=Articulos::altaArticulo($idSubcat,$nombreArticulo,$descripcion,$precio,$stock);            
            
            $hora=date("His");
            $nombre=$idArticuloNuevo."_".$hora.".jpg";

            $destino="../imagenes/$nombreCategoria/$nombre";
            
            copy($_FILES['foto']['tmp_name'], $destino);           
            
          Articulos::actualizaArticulo($idArticuloNuevo,$idSubcat,$nombreArticulo,$descripcion,$precio,$stock,$destino);
  			echo "<h2>Se ha dado de alta el artículo $nombreArticulo</h2>";

		} else {
			echo "ERROR: No admitimos ese tipo de archivo<br>";
		}
	}

  
  
}
 ?>
 <script>
 	document.getElementById("selSubCat").innerHTML
 </script>
<h2>Alta de Artículo</h2>
<form action="admin.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="menu" value="30">
	<label for="idSubcat">Subcategoría: </label>
  <select name="idSubcat" id="selSubCat">
  	<option value="">Seleccione una subcategoría</option>
  <?php 
  foreach ($listado as $indice=>$valor)      
  {
  	echo "<option value='".$valor['idSubcat']."'>".$valor['nombreCategoria']." - ".$valor['nombreSubcat']." </option>";
  }
   ?>
   </select>
  <br>
	<label for="nombreArticulo">Nombre de Artículo: </label>
	<input type="text" name="nombreArticulo" placeholder="Introduzca un nombre">
	<br>
	<label for="descripcion">Descripcion del artículo:</label>
	<br>
	<textarea name="descripcion" cols="30" rows="10" placeholder="Introduzca una descripción"></textarea>
	<br>
	<label for="precio">Precio: </label>
	<input type="text" name="precio" placeholder="Introduzca un precio"> €
	<br>
	<label for="stock">Stock: </label>
	<input type="number" name="stock" value="1">
	<br>
	<label for="foto">Foto: </label>	
	<input type="file" name="foto">
	<br>
	<input type="submit" name="altaArticulo" value="Dar de Alta">
</form>
<hr>
<a href="index.php">Ir al menu principal</a>

