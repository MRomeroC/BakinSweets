
<ul>
	<li>CATEGORIAS</li>
	<li><a href="admin.php?menu=10">Alta de categoria</a></li>
	<li><a href="admin.php?menu=11">Listado de categorias</a></li>
</ul>
<hr>
<ul>
	<li>SUBCATEGORIAS</li>
	<li><a href="admin.php?menu=20">Alta de Subcategoria</a></li>
	<li><a href="admin.php?menu=21">Listado de subcategorias</a></li>
</ul>
<hr>
<ul>
	<li>ARTICULOS</li>
	<li><a href="admin.php?menu=30">Alta de Artículo</a></li>
	<li><a href="admin.php?menu=31">Listado de artículos</a></li>
	<li><a href="admin.php?menu=32">Buscar artículos</a></li>
</ul>
<hr>
<ul>
	<li><a href="index.php?cerraradmin=ok">Cerrar sesion</a></li>
</ul>






