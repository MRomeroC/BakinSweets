<?php 
$idSubcat=$_REQUEST['idSubcat'];
$idCategoria=$_REQUEST['idCategoria'];
$posicion=$_REQUEST['posicion'];
$articulosPorPagina=$_REQUEST['articulosPorPagina'];
$listado=Articulos::listadoArticulos($posicion, $articulosPorPagina, $idSubcat, $idCategoria);	
$datos=Subcategorias::datosCategoriaSubcat($idSubcat);


?>


<section class="col-md-12">
<?php 
echo "<h1>".$datos['nombreCategoria']."</h1>
		<h2>".$datos['nombreSubcat']."</h2>";
?>
<div class="row">
<?php 	
$i=0;	
foreach ($listado as $key => $value) {
$i++;

	echo "<div class='col-md-4'><div style='border: 1px solid #000; height: 150px;  margin: 10px; padding:5px 30px;'>".$value['nombreArticulo'];
	
	echo "<br>".$value['precio'];
	echo "€<br><img src='imagenes/".$value['foto']."' height='70px' width='80px'>";
	echo "<br><a href='indexarticulo.php?idArticulo=".$value['idArticulo']."'><i class='fas fa-search'></i></a> | <a href='indexarticulos.php?idArticulo=".$value['idArticulo']."&idSubcat=$idSubcat&alcarrito=ok'><i class='fas fa-cart-plus'></i></a></div></div>";

	if ($i%3==0) {
		echo "<div class='clearfix visible-md'></div>";
		echo "<hr>";
	}
} ?>

</div>

<hr>

<div class="row text-center">
 <ul class="pagination">

<?php 
	//$articulosPorPagina=6;
	$numArticulos=Articulos::numArticulos($idSubcat);

	$numPaginas=ceil($numArticulos)/$articulosPorPagina;

	for ($i=0; $i < $numPaginas; $i++) { 
		$pagina=$i+1;
		$pos=$i*$articulosPorPagina;
		if ($pos==$posicion) {
			echo "<li class='active'><a href='indexarticulos.php?posicion=$pos&articulosPorPagina=$articulosPorPagina&idSubcat=$idSubcat'>$pagina</a></li>";
		} else {
		echo "<li><a href='indexarticulos.php?posicion=$pos&articulosPorPagina=$articulosPorPagina&idSubcat=$idSubcat&idCategoria=$idCategoria'>$pagina</a></li>";
	}
	}

?>

  </ul>
</div>
</section>	
 

