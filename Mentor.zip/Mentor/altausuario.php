<?php 
include_once "clases.php";

$mensaje="";
if (isset($_REQUEST['registrar'])) {
  $usuario=$_REQUEST['usuario'];
  $clave1=$_REQUEST['clave1'];
  $clave2=$_REQUEST['clave2'];

  if ($usuario!="" AND $clave1!="" AND $clave1==$clave2) {
  	if (Usuarios::buscaUsuarioCorreo($usuario)) {
  	 $mensaje="El usuario ya existe, no se puede repetir.";
  	}else{
  	  Usuarios::altaUsuario($usuario,$clave1);
  	  $mensaje="Usuario dado de alta con exito";
  	}
  }else{
  	$mensaje="Los campos no pueden ser vacios y/o las claves no pueden ser diferentes";
  }
}
 ?>
<section id="altausuario" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <h2>Regístrate en BakinSweets</h2>
                    <p>Completa el siguiente formulario para registrarte en BakinSweets. 
                      <br>
                    Guardaremos los datos que nos proporciones para facilitar tus compras a través de la web.</p>
                    <hr class="bottom-line">
                </div>
                <div id="sendmessage"><?=$mensaje ?></div>
                <form action="altausuario.php" method="post" role="form" class="contactForm">
                    <div class="col-xs-12 left">
                        <h2>Cuenta de usuario</h2>
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Tu email" data-rule="email" data-msg="Introduce un email válido" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave1" id="clave1" placeholder="Tu contraseña" data-rule="minlen:6" data-msg="Introduce al menos 6 caracteres" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="clave2" id="clave2" placeholder="Repite tu contraseña" data-rule="minlen:6" data-msg="Introduce al menos 6 caracteres" />
                            <div class="validation"></div>
                        </div>
                        <h2>Datos de contacto</h2>
                        <div class="form-group">
                            <input type="text" name="nombre" class="form-control form" id="name" placeholder="Tu nombre" data-rule="minlen:3" data-msg="Introduce al menos 3 caracteres" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="apellidos" class="form-control form" id="apellidos" placeholder="Tus apellidos" data-rule="minlen:3" data-msg="Introduce al menos 3 caracteres" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Dirección" data-rule="minlen:8" data-msg="Introduce al menos 8 caracteres" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="text" name="ciudad" class="form-control form" id="ciudad" placeholder="Tu ciudad" data-rule="minlen:3" data-msg="Introduce al menos 3 caracteres" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="number" name="cp" class="form-control form" id="cp" placeholder="Tu C.P." data-rule="minlen:5" data-msg="Introduce al menos 5 dígitos" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <select name="provincia" id="provincia" class="form-control form">
                              <?php 
                                $datos=Usuarios::provincias();
                                foreach ($datos as $key => $value) {
                                  echo "<option value='".$value['idProvincia']."'>".$value['nombreProvincia']."</option>";
                                }
                              ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="number" name="telefono" class="form-control form" id="telefono" placeholder="Tu teléfono." data-rule="minlen:9" data-msg="Introduce al menos 9 dígitos" />
                            <div class="validation"></div>
                        </div>
                    </div>

                    <div class="col-xs-12">
                        <!-- Button -->
                        <button type="submit" id="registrar" name="registrar" class="form contact-form-button light-form-button oswald light">DAR DE ALTA</button>
                    </div>
                </form>

            </div>
        </div>
    </section>
  

  <hr>
  <a href="index.php">Ir a la pagina principal</a>
</body>
</html>
