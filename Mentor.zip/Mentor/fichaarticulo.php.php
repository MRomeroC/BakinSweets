<?php 


	$idArticulo=$_REQUEST['idArticulo'];
include_once "clases.php";
	$datos=Articulos::datosArticulo($idArticulo);


 ?>
<section class="col-md-6">
  <h1>Artículo: <?=$datos['nombreArticulo']?></h1>
  <h3>Categoría: <?=$datos['nombreCategoria']?></h3>
  <h4>Subcategoría: <?=$datos['nombreSubcat']?></h4>
  <div class="row">
      <div class="col-md-6">
        <p><?=$datos['descripcion']?> </p>
        <p>Precio: <?=$datos['precio']?>€</p>  
        <p>Stock: <?=$datos['stock']?></p>
        <h3><a href="fichaarticulo.php?idArticulo=<?=$datos['idArticulo']?>&alcarrito=ok"><i class='fas fa-cart-plus'></i></a></h3>    
      </div>
      <div class="col-md-6">
        <img src='imagenes/<?=$datos['fotoArticulo']?>' alt='<?=$datos['nombreArticulo']?>' width='200'>        
      </div>
  </div>
 	
 </section>
 <hr>
 <a href="index.php">Ir al menu principal</a>

