
<ul>
	<li>CATEGORÍAS</li>
	<li><a href="admin.php?menu=10">Alta de categoría</a></li>
	<li><a href="admin.php?menu=11">Listado de categorías</a></li>
</ul>
<hr>
<ul>
	<li>SUBCATEGORÍAS</li>
	<li><a href="admin.php?menu=20">Alta de Subcategoría</a></li>
	<li><a href="admin.php?menu=21">Listado de subcategorías</a></li>
</ul>
<hr>
<ul>
	<li>ARTÍCULOS</li>
	<li><a href="admin.php?menu=30">Alta de Artículo</a></li>
	<li><a href="admin.php?menu=31">Listado de artículos</a></li>
	<li><a href="admin.php?menu=32">Buscar artículos</a></li>
</ul>
<hr>
<ul>
	<li>PEDIDOS</li>
	<li><a href="admin.php?menu=40">Listado de pedidos</a></li>
	<li><a href="admin.php?menu=41">Buscar pedidos</a></li>
</ul>
<hr>
<ul>
	<li>NEWSLETTERS</li>
	<li><a href="admin.php?menu=50">Enviar Newsletter</a></li>
</ul>
<hr>
<ul>
	<li><a href="index.php?cerraradmin=ok">Cerrar sesión</a></li>
</ul>






