<?php 
$idSubcat=$_REQUEST['idSubcat'];
$idCategoria=$_REQUEST['idCategoria'];
$posicion=$_REQUEST['posicion'];
$articulosPorPagina=$_REQUEST['articulosPorPagina'];
$listado=Articulos::listadoArticulos($posicion, $articulosPorPagina, $idSubcat, $idCategoria);	
$datos=Subcategorias::datosCategoriaSubcat($idSubcat);


?>


<section id="dulces" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="header-section text-center">
                    <?php 
						echo "<h2>".$datos['nombreCategoria']."</h2>
								<h3>".$datos['nombreSubcat']."</h3>";
					?>
                    <hr class="bottom-line">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
<?php 	
	$i=0;	
	foreach ($listado as $key => $value) {
	$i++;
      echo "<div class='col-md-4 col-sm-6 padleft-right'>
                    <figure class='imghvr-fold-up'>
                        <img src='imagenes/".$value['foto']."' class='img-responsive'>
                        <figcaption>
                            <h3>".$value['nombreArticulo']."</h3>
                            <p>".$value['descripcion']."</p>
                            <h4>".$value['precio']."€</h4>
                            <a href='indexarticulo.php?idArticulo=".$value['idArticulo']."'></a>
                        </figcaption>
                        
                    </figure>
                </div>";
    
    if ($i%3==0) {
		echo "<div class='clearfix visible-md'></div>";
		
	}            
    }          
                
                
 ?>   
            </div>
        </div>
    </section>

<hr>

<div class="row text-center">
 <ul class="pagination">

<?php 
	//$articulosPorPagina=6;
	$numArticulos=Articulos::numArticulos($idSubcat);

	$numPaginas=ceil($numArticulos)/$articulosPorPagina;

	for ($i=0; $i < $numPaginas; $i++) { 
		$pagina=$i+1;
		$pos=$i*$articulosPorPagina;
		if ($pos==$posicion) {
			echo "<li class='active'><a href='indexarticulos.php?posicion=$pos&articulosPorPagina=$articulosPorPagina&idSubcat=$idSubcat'>$pagina</a></li>";
		} else {
		echo "<li><a href='indexarticulos.php?posicion=$pos&articulosPorPagina=$articulosPorPagina&idSubcat=$idSubcat&idCategoria=$idCategoria'>$pagina</a></li>";
	}
	}

?>

  </ul>
</div>
</section>	
 

