$(document).ready(function($){

var emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i,
	tlfoExp = /^[9|6|7][0-9]{8}$/,
	cpExp = /^[00-52]{2}[0-9]{3}$/;

	
	$("#formulario").submit(function(){

		$(".validation").fadeOut();

		var usuario=$("#usuario").val();
		var clave1=$("#clave1").val();
		var clave2=$("#clave2").val();
		var nombre=$("#altanombre").val();
		var apellidos=$("#apellidos").val();
		var direccion=$("#direccion").val();
		var ciudad=$("#ciudad").val();
		var cp=$("#cp").val();
		var provincia=$("#provincia").val();
		var telefono=$("#telefono").val();

		/*Si el campo a verificar está vacío mostrará un mensaje de error. Si se rellena, deberá eliminarse el mensaje que se añadió y pasar a comprobar el siguiente campo*/
		if(usuario=="") {
			$("#mensaje1").fadeIn();
            $("#usuario").focus();
			return false;
		} else if(!emailExp.test(usuario)){
			$("#mensaje2").fadeIn();
            $("#usuario").focus();
			return false;
		}else if(clave1=="" || clave1.length<6){
			$("#mensaje3").fadeIn();
            $("#clave1").focus();
			return false;
		} else if(clave2==""){
			$("#mensaje4").fadeIn();
            $("#clave2").focus();
			return false;
		} else if(clave1!=clave2){
			$("#mensaje5").fadeIn();
            $("#clave1").focus();
			return false;
		} else if(nombre==""){
			$("#mensaje6").fadeIn();
            $("#altanombre").focus();
			return false;
		} else if(apellidos=="") {
			$("#mensaje7").fadeIn();
            $("#apellidos").focus();
			return false;
		} else if(direccion=="") {
			$("#mensaje8").fadeIn();
            $("#direccion").focus();
			return false;
		} else if(ciudad=="") {
			$("#mensaje9").fadeIn();
            $("#ciudad").focus();
			return false;
		} else if(cp=="") {
			$("#mensaje10").fadeIn();
            $("#cp").focus();
			return false;
		} else if(!cpExp.test(cp)) {
			$("#mensaje11").fadeIn();
            $("#cp").focus();
			return false;
		} else if(provincia=="0") {
			$("#mensaje12").fadeIn();
            $("#provincia").focus();
			return false;
        } else if(telefono=="") {
			$("#mensaje13").fadeIn();
            $("#telefono").focus();
			return false;    
        } else if (!tlfoExp.test(telefono)) {
			$("#mensaje14").fadeIn();
            $("#telefono").focus();
			return false;
        }//fin ultimo else if

	});

});