<?php  
include_once "clases.php";

$mensajeNews="";

if (isset($_REQUEST['altaNewsletter'])) {

	$email=$_REQUEST['emailNewsletter'];
	if ($email!="") {
		$mensajeNews=Newsletter::insertNewsletter($email);
	}
}
?>